package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import org.mariuszgromada.math.mxparser.*;
public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        previousCalc = findViewById(R.id.previousCalculationView);
        displayText = findViewById(R.id.displayEditText);

        displayText.setShowSoftInputOnFocus(false);

    }

    private TextView previousCalc;
    private EditText displayText;
    Button b0;
    private void updateText(String Str){
        String preStr=displayText.getText().toString();
        int cursor=displayText.getSelectionStart();
        String leftStr=preStr.substring(0,cursor);
        String rightStr=preStr.substring(cursor);

        displayText.setText(String.format("%s%s", preStr, Str));
        displayText.setSelection(cursor + Str.length());
    }

    public void zeroBtn(View view){
        updateText(getResources().getString(R.string.zero));
    }

    public void oneBtn(View view){
        updateText(getResources().getString(R.string.one));
    }

    public void twoBtn(View view){
        updateText(getResources().getString(R.string.two));
    }

    public void threeBtn(View view){
        updateText(getResources().getString(R.string.three));
    }
    public void fourBtn(View view){
        updateText(getResources().getString(R.string.four));
    }
    public void fiveBtn(View view){
        updateText(getResources().getString(R.string.five));
    }
    public void sixBtn(View view){
        updateText(getResources().getString(R.string.six));
    }
    public void sevenBtn(View view){
        updateText(getResources().getString(R.string.seven));
    }
    public void eightBtn(View view){
        updateText(getResources().getString(R.string.eight));
    }
    public void nineBtn(View view){
        updateText(getResources().getString(R.string.nine));
    }
    public void addBtn(View view){
        updateText(getResources().getString(R.string.add));
    }
    public void minusBtn(View view){
        updateText(getResources().getString(R.string.minus));
    }
    public void multiplyBtn(View view){
        updateText(getResources().getString(R.string.multiply));
    }
    public void divideBtn(View view){
        updateText(getResources().getString(R.string.divide));
    }
    public void round0Btn(View view){
        updateText("R0(");
    }
    public void round2Btn(View view){
        updateText("R2(");
    }
    public void squareBtn(View view){
        updateText("^(2)");
    }
    public void squareRootBtn(View view){
        updateText("sqrt(");
    }
    public void piBtn(View view){
        updateText("Pi(");
    }
    public void percentBtn(View view){
        updateText("%");
    }
    public void dotBtn(View view){
        updateText(".");
    }
    public void ClearBtn(View view){
         displayText.setText("");
    }
    public void equalBtn(View view){

          String val=displayText.getText().toString();
        val=val.replaceAll(getResources().getString(R.string.divide), "/");
        val=val.replaceAll(getResources().getString(R.string.multiply), "*");


        Expression exp =new Expression(val);
          String answer=String.valueOf(exp.calculate());
          displayText.setText(answer);
          displayText.setSelection(answer.length());


    }
    public void backBtn(View view){

        int cursor= displayText.getSelectionStart();
        int textLen=displayText.getText().length();

        if(cursor !=0 && textLen !=0){
            SpannableStringBuilder select= (SpannableStringBuilder) displayText.getText();
            select.replace( cursor-1, cursor, "");
            displayText.setText(select);
            displayText.setSelection(cursor-1);
        }

    }
    public void yRootBtn(View view){

        updateText("y√x(");
    }
    public void xyBtn(View view)
    {
        updateText("^(");
    }
    public void naturalBtn(View view){

        updateText("ln(");
    }
    public void closeBtn(View view){
        updateText(")");
    }
    public void openBtn(View view){

        updateText("(");
    }
    public void cubeBtn(View view){
        updateText("^(3)");
    }
    public void factorialBtn(View view){
        updateText("!");
    }
    public void ExBtn(View view){
        updateText("e^(");
    }
    public void logBtn(View view){
        updateText("log(");
    }
    public void tan1Btn(View view){
        updateText("tan-1(");
    }
    public void cos1Btn(View view){
        updateText("cos-1(");;
    }
    public void sin1Btn(View view){
        updateText("sin-1(");
    }
    public void tanBtn(View view){
        updateText("tan(");
    }
    public void cosBtn(View view){

        updateText("cos(");
    }
    public void sinBtn(View view){

        updateText("sin(");
    }




}

